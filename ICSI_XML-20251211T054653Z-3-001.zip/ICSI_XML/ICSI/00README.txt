ICSI Signals and Annotations public release 1.0

Please read LICENCE.txt before using this data.

Please quote the release number in any correspondence.

The annotation data is in a format ready to be used directly by
NXT. Download and further information here:
 http://groups.inf.ed.ac.uk/nxt/

To use this data with ICSI media files, make sure the signals you have
downloaded from http://corpus.amiproject.org/ are in a directory
called 'Signals' under this directory.


